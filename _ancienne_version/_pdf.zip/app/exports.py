"""Exports PDF et CSV (Excel) du planning mensuel."""
import csv
import io
import re
import unicodedata


from .config import BASE_DIR
from .services import MOIS_FR, PlanningMois

ASSETS = BASE_DIR / "app" / "pdf_assets"
ASSETS_FONTS = BASE_DIR / "app" / "fonts"


def _latin1(texte: str) -> str:
    """Les polices PDF intégrées ne gèrent que le latin-1 : on remplace le reste proprement."""
    remplacements = {"’": "'", "‘": "'", "“": '"', "”": '"', "–": "-", "—": "-", "…": "...", "œ": "oe", "Œ": "OE"}
    for a, b in remplacements.items():
        texte = texte.replace(a, b)
    try:
        texte.encode("latin-1")
        return texte
    except UnicodeEncodeError:
        normalise = unicodedata.normalize("NFKD", texte)
        return normalise.encode("latin-1", "ignore").decode("latin-1")


def nom_fichier(nom_eglise: str, planning: PlanningMois, extension: str) -> str:
    base = unicodedata.normalize("NFKD", nom_eglise).encode("ascii", "ignore").decode()
    base = re.sub(r"[^a-zA-Z0-9]+", "_", base).strip("_").lower() or "eglise"
    return f"planning_{base}_{planning.mois:02d}_{planning.annee}.{extension}"


def _hex(c: str):
    from reportlab.lib.colors import HexColor
    return HexColor(c)


_FONTS_OK = False


def _polices() -> None:
    global _FONTS_OK
    if _FONTS_OK:
        return
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    for nom in ("InterDisplay-ExtraBold", "Inter-Regular", "Inter-SemiBold", "Inter-Bold"):
        pdfmetrics.registerFont(TTFont(nom, str(ASSETS_FONTS / f"{nom}.ttf")))
    _FONTS_OK = True


def _lignes(texte: str, police: str, taille: float, largeur: float):
    """Découpe un texte en lignes tenant dans la largeur donnée."""
    from reportlab.pdfbase.pdfmetrics import stringWidth
    mots, lignes, courante = texte.split(), [], ""
    for mot in mots:
        essai = f"{courante} {mot}".strip()
        if stringWidth(essai, police, taille) <= largeur or not courante:
            courante = essai
        else:
            lignes.append(courante)
            courante = mot
    if courante:
        lignes.append(courante)
    return lignes or [""]


def planning_pdf(nom_eglise: str, planning: PlanningMois, couleur: dict, prochain=None) -> bytes:
    """PDF A4 paysage dans le style de l'application : une colonne par dimanche."""
    import io as _io
    from datetime import date as _date
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.pdfbase.pdfmetrics import stringWidth
    from reportlab.pdfgen import canvas

    _polices()
    W, H = landscape(A4)
    M = 34
    buf = _io.BytesIO()
    c = canvas.Canvas(buf, pagesize=(W, H))
    c.setTitle(f"Planning {MOIS_FR[planning.mois]} {planning.annee} - {nom_eglise}")
    c.setAuthor(nom_eglise)

    noir, gris, filet, papier = _hex("#0A0A0A"), _hex("#6B6D73"), _hex("#DCDDD9"), _hex("#F1F1EE")
    acc, acc_clair = _hex(couleur["acc"]), _hex(couleur["light"])

    # Logo en filigrane, en bas à droite
    try:
        c.drawImage(str(ASSETS / "mark-dark.png"), W - 400, -170, width=470, height=470 * 409 / 281, mask="auto")
    except Exception:  # noqa: BLE001
        pass

    # En-tête
    try:
        from reportlab.lib.utils import ImageReader
        logo = ImageReader(str(ASSETS / "logo.png"))
        lw, lh = logo.getSize()
        c.drawImage(logo, M, H - M - 40, height=40, width=40 * lw / lh, mask="auto")
    except Exception:  # noqa: BLE001
        pass
    c.setFillColor(gris); c.setFont("Inter-SemiBold", 9.5)
    c.drawRightString(W - M, H - M - 12, nom_eglise)
    c.drawRightString(W - M, H - M - 26, "Planning des cultes")

    titre_y = H - M - 98
    c.setFillColor(noir); c.setFont("InterDisplay-ExtraBold", 56)
    mois = MOIS_FR[planning.mois]
    c.drawString(M - 2, titre_y, mois)
    c.setFillColor(_hex("#C2C4C9"))
    c.drawString(M - 2 + stringWidth(mois + " ", "InterDisplay-ExtraBold", 56), titre_y, str(planning.annee))

    total, manquantes = planning.places_totales, planning.places_manquantes
    resume = f"{len(planning.dimanches)} dimanches, {total - manquantes} places pourvues sur {total}"
    if manquantes:
        resume += f", {manquantes} à pourvoir"
    c.setFillColor(gris); c.setFont("Inter-Regular", 10.5)
    c.drawString(M, titre_y - 22, resume)

    # Colonnes
    n = max(1, len(planning.dimanches))
    gap = 10
    top = titre_y - 44
    bottom = M + 22
    col_w = (W - 2 * M - gap * (n - 1)) / n
    pad = 14
    inner = col_w - 2 * pad
    roles = planning.lignes
    par_jour = planning.par_dimanche()

    # Hauteur de chaque rôle = la plus grande parmi les dimanches (lignes alignées)
    def mesure(echelle):
        haut = []
        for i, ligne in enumerate(roles):
            h_max = 0
            for cell in ligne.cellules:
                nb = sum(len(_lignes(nom, "Inter-Bold", 11.5 * echelle, inner)) for nom in cell.noms) or 1
                h_role = len(_lignes(ligne.role.nom, "Inter-Regular", 8 * echelle, inner))
                h_max = max(h_max, (h_role * 10 + nb * 14.5) * echelle + 14 * echelle)
            haut.append(h_max)
        return haut

    tete = 72
    echelle = 1.45
    hauteurs = mesure(echelle)
    while tete + sum(hauteurs) + 8 > top - bottom and echelle > 0.6:
        echelle -= 0.05
        hauteurs = mesure(echelle)
    col_h = tete + sum(hauteurs) + 8

    for j, d in enumerate(planning.dimanches):
        x = M + j * (col_w + gap)
        y_haut = top
        actif = prochain is not None and d == prochain
        c.saveState()
        if actif:
            c.setFillColor(acc)
        else:
            c.setFillColor(papier); c.setFillAlpha(0.78)
        c.roundRect(x, y_haut - col_h, col_w, col_h, 14, stroke=0, fill=1)
        c.restoreState()

        texte, secondaire, ligne_sep = (_hex("#FFFFFF"), acc_clair, _hex("#FFFFFF")) if actif else (noir, gris, filet)
        c.setFillColor(texte); c.setFont("InterDisplay-ExtraBold", 40)
        c.drawString(x + pad - 1, y_haut - 46, f"{d.day:02d}")
        c.setFillColor(secondaire); c.setFont("Inter-SemiBold", 8.5)
        c.drawString(x + pad, y_haut - 61, "Prochain culte" if actif else "Dimanche")

        y = y_haut - tete
        for i, ligne in enumerate(roles):
            cell = ligne.cellules[j]
            c.saveState()
            c.setStrokeColor(ligne_sep); c.setLineWidth(0.6)
            if actif:
                c.setStrokeAlpha(0.3)
            c.line(x + pad, y, x + col_w - pad, y)
            c.restoreState()
            yy = y - 13 * echelle
            c.setFillColor(secondaire); c.setFont("Inter-Regular", 8 * echelle)
            for l in _lignes(ligne.role.nom, "Inter-Regular", 8 * echelle, inner):
                c.drawString(x + pad, yy, l); yy -= 10 * echelle
            yy -= 4 * echelle
            if cell.noms:
                c.setFillColor(texte); c.setFont("Inter-Bold", 11.5 * echelle)
                for nom in cell.noms:
                    for l in _lignes(nom, "Inter-Bold", 11.5 * echelle, inner):
                        c.drawString(x + pad, yy, l); yy -= 14.5 * echelle
            else:
                label = "À pourvoir"
                lw = stringWidth(label, "Inter-Bold", 8.5) + 14
                c.setFillColor(_hex("#FFFFFF") if actif else noir)
                c.roundRect(x + pad, yy - 4, lw, 14, 7, stroke=0, fill=1)
                c.setFillColor(acc if actif else _hex("#FFFFFF")); c.setFont("Inter-Bold", 8.5)
                c.drawString(x + pad + 7, yy, label)
            y -= hauteurs[i]

    c.setFillColor(gris); c.setFont("Inter-Regular", 8)
    aujourd_hui = _date.today()
    c.drawString(M, M - 4, f"Édité le {aujourd_hui.day} {MOIS_FR[aujourd_hui.month].lower()} {aujourd_hui.year} avec Planning EJP")
    c.showPage()
    c.save()
    return buf.getvalue()


def planning_csv(planning: PlanningMois) -> bytes:
    sortie = io.StringIO()
    writer = csv.writer(sortie, delimiter=";")
    writer.writerow(["Rôle"] + [d.strftime("%d/%m/%Y") for d in planning.dimanches])
    for ligne in planning.lignes:
        writer.writerow([ligne.role.nom] + [", ".join(c.noms) if c.noms else "-" for c in ligne.cellules])
    return sortie.getvalue().encode("utf-8-sig")
